package mkp;

import java.awt.Point;

public class MKPXMLer {



	static public String buildCloseXML() {


                  StringBuilder buffer = new StringBuilder();

                    buffer.append("<COMMAND name=\"CLOSE\">");
                    buffer.append("</COMMAND>");
		 return buffer.toString();
	}

	static public String buildClearXML() {

                  StringBuilder buffer = new StringBuilder();

                    buffer.append("<COMMAND name=\"CLEAR\">");
                    buffer.append("</COMMAND>");
		 return buffer.toString();

	}

	static public String buildMarkXML(Point p1,Point p2) {

                  StringBuilder buffer = new StringBuilder();

                    buffer.append("<COMMAND name=\"MARK\">");
                    buffer.append("</COMMAND>");
		 return buffer.toString();
	}
}
