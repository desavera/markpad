package mkp;

import java.net.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Line2D;
import java.util.ArrayList;
import javax.swing.*;

import rpn.message.RPnNetworkStatus;
import rpn.message.RPnNetworkDialog;

public class PadDrawing extends JPanel implements MouseMotionListener, MouseListener{

    Point point1_;
    Point point2_;
    Boolean doClear_;

    protected MKPGlassFrame parentFrame_;

  public PadDrawing(MKPGlassFrame parentFrame) {

       super();

       doClear_ = false;
       parentFrame_ = parentFrame;
       point1_ = new Point();
       point2_ = new Point();
       setDoubleBuffered(false);
       addMouseListener(this);
       addMouseMotionListener(this);
    }

 @Override
  public void paintComponent(Graphics g){

    super.paintComponent(g);

    Graphics2D g2d = (Graphics2D) g;
    if(point1_!=null && point2_!=null && !doClear_){

          g2d.setPaint(Color.RED);
          g2d.setStroke(new BasicStroke(2.0f));

	  if(parentFrame_.getGlassState() == MKPGlassFrame.CONFIGURED_GLASS_STATE)
          	g2d.fillRect(point1_.x,
                       point1_.y,
                       point2_.x - point1_.x,
                       point2_.y - point1_.y);
	  else // INIT
          	g2d.drawRect(point1_.x,
                       point1_.y,
                       point2_.x - point1_.x,
                       point2_.y - point1_.y);
    }

    if (doClear_) {
	g2d.clearRect(0,0,getWidth(),getHeight());
	doClear_ = false;
    }
  }   

  public void mark(Point point1,Point point2) {

	point1_ = point1;
	point2_ = point2;

	invalidate();
	repaint();

  }

  public void clear() {
        
	point1_ = new Point();
	point2_ = new Point();
	doClear_ = true;

        invalidate();
        repaint();

        if (RPnNetworkStatus.instance().isOnline() && RPnNetworkStatus.instance().isMaster())
		RPnNetworkStatus.instance().sendCommand(MKPXMLer.buildClearXML());
  }

  @Override
  public void mouseDragged(MouseEvent e) {

    point2_ = e.getPoint();
    repaint();

  }

  @Override
  public void mouseMoved(MouseEvent e) {

  }

  @Override
  public void mouseClicked(MouseEvent e) {

     if(e.getClickCount() == 2)
	clear();
  }

  @Override
  public void mousePressed(MouseEvent e) {

     point1_ = e.getPoint();

  }

  @Override
  public void mouseReleased(MouseEvent e) {
	

	if (SwingUtilities.isRightMouseButton(e)) {

		MKPControlMenu menu = new MKPControlMenu(this);
        	menu.show(e.getComponent(), e.getX(), e.getY());

	} 

	if ((parentFrame_.getGlassState() == MKPGlassFrame.CONFIGURED_GLASS_STATE) && 
	 (RPnNetworkStatus.instance().isOnline()) && (RPnNetworkStatus.NO_BUS_CONTROL_)) {

		RPnNetworkStatus.instance().sendCommand(MKPXMLer.buildMarkXML(point1_,point2_));
		invalidate();
		repaint();
	}

	if (parentFrame_.getGlassState() == MKPGlassFrame.INIT_GLASS_STATE) {
	
		parentFrame_.setGlassState(MKPGlassFrame.CONFIGURED_GLASS_STATE);
		parentFrame_.setBounds(new Rectangle(point1_.x,point1_.y,point2_.x - point1_.x,point2_.y - point1_.y));
		clear();
	}


 }

 @Override
 public void mouseEntered(MouseEvent e) {

 }

 @Override
 public void mouseExited(MouseEvent e) {

 }


}

class MKPControlMenu extends JPopupMenu {


	JMenuItem connect_ = new JMenuItem("Connect");
	JMenuItem disconnect_ = new JMenuItem("Disconnect");
	JMenuItem clear_ = new JMenuItem("Clear");
	JMenuItem exit_ = new JMenuItem("Exit");

	PadDrawing renderer_;

	public MKPControlMenu(PadDrawing renderer) {


		renderer_ = renderer;

		disconnect_.setEnabled(false);

		add(connect_);
		add(disconnect_);
		add(clear_);
		add(exit_);


		connect_.addActionListener(
                new java.awt.event.ActionListener() {

                    public void actionPerformed(ActionEvent e) {

			try {

            			String clientID = InetAddress.getLocalHost().getHostName();
				RPnNetworkStatus.instance().connect(clientID,false,true);

			 } catch (UnknownHostException ex) {
                    		System.out.println(ex);
        		}
                    }
                });

		disconnect_.addActionListener(
                new java.awt.event.ActionListener() {

                    public void actionPerformed(ActionEvent e) {

			try {

	            		String clientID = InetAddress.getLocalHost().getHostName();
				RPnNetworkStatus.instance().disconnect();

			 } catch (UnknownHostException ex) {
                    		System.out.println(ex);
        		}
                    }
                });

		clear_.addActionListener(
                new java.awt.event.ActionListener() {

                    public void actionPerformed(ActionEvent e) {

			renderer_.clear();

                    }
                });


		exit_.addActionListener(
                new java.awt.event.ActionListener() {

                    public void actionPerformed(ActionEvent e) {

			renderer_.parentFrame_.execCloseCommand();

                    }
                });

	}
}
